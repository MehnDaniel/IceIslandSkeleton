package projlab.iceisland;

import java.util.Scanner;

public class IceIslandApplication {

    public static void main(String[] args) {
        while (true){
            Console.testCases();
            System.out.println("press a key then enter to continue");
            Scanner scanner = new Scanner(System.in);
            scanner.next();
        }
    }
}
