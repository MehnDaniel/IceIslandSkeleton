package projlab.iceisland.model;

public enum Building {
    NoBuilding, Igloo
}
