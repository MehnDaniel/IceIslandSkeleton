package projlab.iceisland.model;

public interface IUpdatable {
    void update();
}

